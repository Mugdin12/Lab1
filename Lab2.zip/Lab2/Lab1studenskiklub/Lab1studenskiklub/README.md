Studentski klub

1. Dodavanje novog modela i relacije
Kreiran je novi model Registration koji prestavlja prijavu korisnika i povezan je sa modelima member i event pomocu ManyToOne relacije.
2. Funkcionalnosti kontrolera
RegistrationController Omogucava prikaz, dodavanje i izmjenu prijava clanova na dogadjaje
3. Konfiguracija baze podataka
Aplikacija povezana sa h2 relacionom bazom podataka pomocu Spring Data JPA. Konfiguracija definisana u aplication,properties, a Hibernate automatski kreira i azurira tabele.
Clanovi tima 
Student A : Ramo Kuduzovic
Student B : Suljo Suljic