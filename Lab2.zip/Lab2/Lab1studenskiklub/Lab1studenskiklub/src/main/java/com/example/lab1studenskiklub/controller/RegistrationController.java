package com.example.lab1studenskiklub.controller;

import com.example.lab1studenskiklub.model.Registration;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import com.example.lab1studenskiklub.repository.EventRepository;
import com.example.lab1studenskiklub.repository.MemberRepository;
import com.example.lab1studenskiklub.repository.RegistrationRepository;
import java.time.LocalDate;
@Controller
public class RegistrationController {
    private final RegistrationRepository registrationRepository;
    private final EventRepository eventRepository;
    private final MemberRepository memberRepository;
    public RegistrationController(RegistrationRepository registrationRepository,
    EventRepository eventRepository,
    MemberRepository memberRepository) {
        this.registrationRepository = registrationRepository;
        this.eventRepository = eventRepository;
        this.memberRepository = memberRepository;
    }
    @GetMapping("/registrations")
    public String registration(Model model) {
        model.addAttribute("registration",registrationRepository.findAll());
        return "registration";
    }

    @GetMapping("/registrations/new")
    public String registrationForm(Model model) {
        model.addAttribute("members",memberRepository.findAll());
        model.addAttribute("events",eventRepository.findAll());
        return "registration-form";
    }
    @PostMapping("/registrations/save")
    public String saveRegistration(@RequestParam Long memberId,
    @RequestParam Long eventId) {
        var member = memberRepository.findById(memberId);
        var event = eventRepository.findById(eventId);
        if(member.isEmpty() || event.isEmpty()){
            return "redirect:/registrations/new";
        }
        Registration registration=new Registration(
                member.get(),
                event.get(),
                LocalDate.now(),
                "Pending"
        );
        registrationRepository.save(registration);
        return "redirect:/registrations";
    }
    @GetMapping("/registrations/edit/{id}")
    public String editRegistration(@PathVariable Long id, Model model) {
        Registration registration = registrationRepository.findById(id).orElse(null);
        if(registration == null){
            return "redirect:/registrations";
        }
        model.addAttribute("registration",registration);
        model.addAttribute("members",memberRepository.findAll());
        model.addAttribute("events",eventRepository.findAll());
        return "registration-edit";
    }
    @PostMapping("/registrations/update/{id}")
    public String updateRegistration(
            @PathVariable Long id,
            @RequestParam Long memberId,
            @RequestParam Long eventId,
            @RequestParam String status
    ){
        Registration registration = registrationRepository.findById(id).orElse(null);
        if(registration == null){
            return "redirect:/registrations";
        }
        var member = memberRepository.findById(memberId);
        var event = eventRepository.findById(eventId);
        if(member.isEmpty() || event.isEmpty()){
            return "redirect:/registrations/edit/" + id;
        }
        registration.setStatus(status);
        registration.setMember(member.get());
        registration.setEvent(event.get());
        registrationRepository.save(registration);
        return "redirect:/registrations";
    }
}
