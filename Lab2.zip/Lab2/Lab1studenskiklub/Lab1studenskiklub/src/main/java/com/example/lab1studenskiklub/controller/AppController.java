package com.example.lab1studenskiklub.controller;
import com.example.lab1studenskiklub.data.DemoData;
import com.example.lab1studenskiklub.model.Event;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import com.example.lab1studenskiklub.repository.EventRepository;
import com.example.lab1studenskiklub.repository.MemberRepository;

@Controller
public class AppController {
    @GetMapping("/a")
    public String events(Model model){
        model.addAttribute("events",DemoData.Events);
        model.addAttribute("events",eventRepository.findAll());
        return "ListA";
    }
    @GetMapping ("/b")
    public String members(Model model){
        model.addAttribute("members",DemoData.Members);
        model.addAttribute("members",memberRepository.findAll());
        return "ListB";
    }

    @GetMapping ("/a/action/{id}")
    public String action (@PathVariable long id, Model model){

        Event event = eventRepository.findById(id).orElse(null);
        if(event == null){
            return "redirect:/a";
        }


        model.addAttribute("event", event);
        return "action";
    }

    @PostMapping ("/a/action/{id}")
    public String confirmAction(@PathVariable int id){
        return "redirect:/a";
    }
    private final EventRepository eventRepository;
    private final MemberRepository memberRepository;
    public AppController(EventRepository eventRepository, MemberRepository memberRepository) {
        this.eventRepository = eventRepository;
        this.memberRepository = memberRepository;
    }

}
