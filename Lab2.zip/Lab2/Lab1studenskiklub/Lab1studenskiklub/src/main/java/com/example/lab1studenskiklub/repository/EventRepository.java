package com.example.lab1studenskiklub.repository;
import com.example.lab1studenskiklub.model.Event;
import org.springframework.data.jpa.repository.JpaRepository;
public interface EventRepository extends JpaRepository<Event, Long>{
}

