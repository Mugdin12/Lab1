package com.example.lab1studenskiklub.repository;
import com.example.lab1studenskiklub.model.Registration;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
public interface RegistrationRepository extends JpaRepository<Registration,Long> {
    List<Registration> findByMemberId(Long memberId);
    List<Registration> findByEventId(Long eventId);
}