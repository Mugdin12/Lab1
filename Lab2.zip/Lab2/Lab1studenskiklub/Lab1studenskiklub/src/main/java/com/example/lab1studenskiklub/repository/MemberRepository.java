package com.example.lab1studenskiklub.repository;
import com.example.lab1studenskiklub.model.Member;
import org.springframework.data.jpa.repository.JpaRepository;
public interface MemberRepository extends JpaRepository<Member,Long>{
}


