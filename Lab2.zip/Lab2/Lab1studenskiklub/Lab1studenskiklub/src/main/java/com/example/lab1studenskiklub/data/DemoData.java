package com.example.lab1studenskiklub.data;
import com.example.lab1studenskiklub.model.Event;
import com.example.lab1studenskiklub.model.Member;
import java.util.ArrayList;
import java.util.List;
public class DemoData {
    public static List<Event> Events = new ArrayList<>();
    public static List<Member> Members = new ArrayList<>();

    static {
        Events.add(new Event(1,"Java Workshop","Radionica iz Jave","25.10.2026.","Zenica"));
        Events.add(new Event(2,"Student Party","Druzzene studenata","30.10.2026.","Studenski centar"));
        Members.add(new Member(1,"Ramo","Kuduzovic","mk@gmail.com","Software engeering",1));
        Members.add(new Member(2,"Suljo","Suljic","sk@gmail.com","Computer Science",2));
    }
}
