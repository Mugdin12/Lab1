package com.example.lab1studenskiklub.controller;

import com.example.lab1studenskiklub.model.Event;
import com.example.lab1studenskiklub.model.Member;
import com.example.lab1studenskiklub.model.Registration;
import com.example.lab1studenskiklub.repository.EventRepository;
import com.example.lab1studenskiklub.repository.MemberRepository;
import com.example.lab1studenskiklub.repository.RegistrationRepository;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Controller
public class AppController {

    private final EventRepository eventRepository;
    private final MemberRepository memberRepository;
    private final RegistrationRepository registrationRepository;

    public AppController(EventRepository eventRepository,
                         MemberRepository memberRepository,
                         RegistrationRepository registrationRepository) {
        this.eventRepository = eventRepository;
        this.memberRepository = memberRepository;
        this.registrationRepository = registrationRepository;
    }

    @GetMapping("/")
    public String home() {
        return "redirect:/a";
    }

    @GetMapping("/a")
    public String events(Model model) {
        List<Event> events = eventRepository.findAll();
        List<Registration> allRegistrations = registrationRepository.findAll();

        Map<Long, Long> registrationCounts = new HashMap<>();
        for (Event event : events) {
            long count = allRegistrations.stream()
                    .filter(r -> r.getEvent().getId().equals(event.getId()))
                    .count();
            registrationCounts.put(event.getId(), count);
        }

        model.addAttribute("events", events);
        model.addAttribute("registrationCounts", registrationCounts);
        return "listA";
    }

    @GetMapping("/b")
    public String members(Model model) {
        List<Member> members = memberRepository.findAll();
        List<Registration> allRegistrations = registrationRepository.findAll();

        Map<Long, List<String>> memberEventsMap = new HashMap<>();
        for (Member member : members) {
            memberEventsMap.put(member.getId(), new ArrayList<>());
        }
        for (Registration reg : allRegistrations) {
            Long mId = reg.getMember().getId();
            if (memberEventsMap.containsKey(mId)) {
                memberEventsMap.get(mId).add(reg.getEvent().getName());
            }
        }

        model.addAttribute("members", members);
        model.addAttribute("memberEventsMap", memberEventsMap);
        return "listB";
    }

    @GetMapping("/a/action/{id}")
    public String action(@PathVariable Long id,
                         @RequestParam(required = false) Boolean success,
                         Model model) {
        Event event = eventRepository.findById(id).orElse(null);
        if (event == null) {
            return "redirect:/a";
        }

        model.addAttribute("event", event);
        model.addAttribute("registrations", registrationRepository.findByEventId(id));
        model.addAttribute("members", memberRepository.findAll());
        model.addAttribute("success", success != null && success);
        return "action";
    }

    @PostMapping("/a/action/{id}")
    public String confirmAction(@PathVariable Long id, @RequestParam Long memberId) {
        Event event = eventRepository.findById(id).orElse(null);
        Member member = memberRepository.findById(memberId).orElse(null);

        if (event == null) {
            return "redirect:/a";
        }
        if (member != null) {
            registrationRepository.save(new Registration(member, event, LocalDate.now(), "Confirmed"));
        }
        return "redirect:/a/action/" + id + "?success=true";
    }
}
