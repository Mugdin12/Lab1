package com.example.lab1studenskiklub.data;

import com.example.lab1studenskiklub.model.Event;
import com.example.lab1studenskiklub.model.Member;
import com.example.lab1studenskiklub.model.Registration;
import com.example.lab1studenskiklub.repository.EventRepository;
import com.example.lab1studenskiklub.repository.MemberRepository;
import com.example.lab1studenskiklub.repository.RegistrationRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.time.LocalDate;

@Component
public class DataInitializer implements CommandLineRunner {

    private final EventRepository eventRepository;
    private final MemberRepository memberRepository;
    private final RegistrationRepository registrationRepository;

    public DataInitializer(EventRepository eventRepository,
                           MemberRepository memberRepository,
                           RegistrationRepository registrationRepository) {
        this.eventRepository = eventRepository;
        this.memberRepository = memberRepository;
        this.registrationRepository = registrationRepository;
    }

    @Override
    public void run(String... args) {
        if (eventRepository.count() == 0 && memberRepository.count() == 0) {
            Event e1 = eventRepository.save(new Event("Java Workshop", "Radionica iz Jave i Spring Boota", "25.10.2026.", "Zenica"));
            Event e2 = eventRepository.save(new Event("Student Party", "Druzenje studenata", "30.10.2026.", "Studentski centar"));
            Event e3 = eventRepository.save(new Event("Hackathon", "Timsko programiranje 24h", "10.11.2026.", "IT Centar"));

            Member m1 = memberRepository.save(new Member("Ramo", "Kuduzovic", "mk@gmail.com", "Software Engineering"));
            Member m2 = memberRepository.save(new Member("Suljo", "Suljic", "sk@gmail.com", "Computer Science"));
            Member m3 = memberRepository.save(new Member("Amina", "Hodzic", "amina@gmail.com", "Software Engineering"));

            registrationRepository.save(new Registration(m1, e1, LocalDate.now(), "Confirmed"));
            registrationRepository.save(new Registration(m2, e2, LocalDate.now(), "Pending"));
            registrationRepository.save(new Registration(m3, e1, LocalDate.now(), "Confirmed"));
        }
    }
}
