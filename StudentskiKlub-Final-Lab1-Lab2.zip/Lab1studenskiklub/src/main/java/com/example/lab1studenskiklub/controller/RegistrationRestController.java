package com.example.lab1studenskiklub.controller;

import com.example.lab1studenskiklub.model.Registration;
import com.example.lab1studenskiklub.repository.RegistrationRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/registrations")
public class RegistrationRestController {

    private final RegistrationRepository registrationRepository;

    public RegistrationRestController(RegistrationRepository registrationRepository) {
        this.registrationRepository = registrationRepository;
    }

    @GetMapping
    public List<Registration> getAllRegistrations() {
        return registrationRepository.findAll();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Registration> getRegistrationById(@PathVariable Long id) {
        return registrationRepository.findById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @GetMapping("/event/{eventId}")
    public List<Registration> getRegistrationsByEvent(@PathVariable Long eventId) {
        return registrationRepository.findByEventId(eventId);
    }

    @GetMapping("/member/{memberId}")
    public List<Registration> getRegistrationsByMember(@PathVariable Long memberId) {
        return registrationRepository.findByMemberId(memberId);
    }
}
