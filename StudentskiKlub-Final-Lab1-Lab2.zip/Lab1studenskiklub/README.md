# Studentski klub — Finalna objedinjena verzija (Lab 1 + Lab 2)

## Naziv aplikacije
**Studentski klub** — Spring Boot MVC + REST API web aplikacija povezana sa relacionom H2 bazom podataka (spremna za dalju nadogradnju u Lab 3).

## Članovi tima
- **Student A:** Ramo Kuduzović
- **Student B:** Suljo Suljić

## 1. Opis modela i ostvarenih relacija
1. **`Event` (Model A):** Entitet koji predstavlja događaj u organizaciji studentskog kluba (`id`, `name`, `description`, `date`, `location`).
2. **`Member` (Model B):** Entitet koji predstavlja člana studentskog kluba (`id`, `firstname`, `lastname`, `email`, `studyProgram`).
3. **`Registration` (Model C — dodan u Lab 2):** Posrednički entitet koji predstavlja prijavu člana na događaj (`id`, `member`, `event`, `registrationDate`, `status`).
   - `@ManyToOne` prema entitetu `Member` (`member_id`) — jedan član može imati više prijava (`1:N`).
   - `@ManyToOne` prema entitetu `Event` (`event_id`) — jedan događaj može imati više prijava (`1:N`).
   - Time je između `Member` i `Event` ostvarena relacija više-prema-više (`N:M`) sa dodatnim atributima (datum prijave i status).

## 2. Opis funkcionalnosti kontrolera
1. **`AppController` (`@Controller` — osnovni MVC prikaz iz Lab 1 povezan na bazu):**
   - `GET /` i `GET /a` — Prikaz liste svih događaja i broja prijava (`listA.html`).
   - `GET /b` — Prikaz liste svih članova i njihovih prijavljenih događaja (`listB.html`).
   - `GET /a/action/{id}` i `POST /a/action/{id}` — Prikaz detalja događaja, prijavljenih članova i brza prijava člana na događaj (`action.html`).
2. **`RegistrationController` (`@Controller` — Thymeleaf MVC kontroler za novi model):**
   - `GET /registrations` — Prikazuje tabelu svih prijava iz baze podataka (`registration.html`).
   - `GET /registrations/new` — Prikazuje formu za unos nove prijave (`registration-form.html`).
   - `POST /registrations/save` — Snima novu prijavu u bazu podataka.
   - `GET /registrations/edit/{id}` — Otvara formu za izmjenu postojeće prijave (`registration-edit.html`).
   - `POST /registrations/update/{id}` — Ažurira (update) postojeću prijavu u bazi podataka.
   - `POST /registrations/delete/{id}` — Briše prijavu iz baze podataka.
3. **`RegistrationRestController` (`@RestController` — REST API JSON kontroler za novi model):**
   - `GET /api/registrations` — Vraća listu svih prijava u JSON formatu.
   - `GET /api/registrations/{id}` — Vraća pojedinačnu prijavu po ID-u u JSON formatu.
   - `GET /api/registrations/event/{eventId}` — Vraća sve prijave za određeni događaj u JSON formatu.
   - `GET /api/registrations/member/{memberId}` — Vraća sve prijave za određenog člana u JSON formatu.

## 3. Opis konfiguracije baze podataka
- U `pom.xml` su dodate zavisnosti `spring-boot-starter-data-jpa`, `com.h2database:h2` i `spring-boot-starter-thymeleaf`.
- U `application.properties` je podešena fajl-bazirana H2 relaciona baza (`jdbc:h2:file:./data/studenski_klub`), automatsko generisanje i ažuriranje tabela (`spring.jpa.hibernate.ddl-auto=update`), ispis SQL upita u konzoli (`spring.jpa.show-sql=true`) i H2 konzola na `/h2-console`.
- Klasa `DataInitializer` (`CommandLineRunner`) prilikom prvog pokretanja upisuje početne događaje, članove i prijave u bazu podataka umjesto nekadašnjih in-memory lista.
